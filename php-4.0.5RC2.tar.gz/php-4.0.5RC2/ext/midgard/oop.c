/* $Id: oop.c,v 1.10 2001/03/04 21:54:00 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

typedef char *charp;
void mgd_object_init(zval *obj, ...)
{
/* TODO: DG: not needed anymore cause php_midgard_bless initializes the object
 * with all the properties (didn't check everywhere yet though)

va_list args;
char *propname;

   va_start(args, obj);
   while ((propname = va_arg(args, charp)) != NULL) {
      add_property_unset(obj, propname);
   }
   va_end(args);
*/
}

void php_midgard_bless(zval *object, MidgardClass *species)
{
	object_init_ex(object, species->entry_ptr);
	php_midgard_ctor(object, species);
}

void php_midgard_ctor(zval *object, MidgardClass *species)
{
	MidgardProperty *midgard_props;

	/* add default properties */
	add_property_string(object, "__table__", (char*)species->table, 1);
	add_property_long(object, "id", 0);
	add_property_long(object, "sitegroup", 0);

	/* add other properties */
	for (midgard_props = species->properties; midgard_props && 
							midgard_props->name; midgard_props++) {
		switch(midgard_props->type) {
			case IS_LONG:
				add_property_long(object, midgard_props->name, 0);
				break;
			case IS_STRING:
				add_property_string(object, midgard_props->name, "", 1);
				break;
			default: /* should not happen, but just in case */
				add_property_unset(object, midgard_props->name);
				break;
		}
	}
}

void php_midgard_bless_oop(zval *object, MidgardClass *species)
{
   object_init_ex(object, species->entry_ptr);

	add_property_string(object, "__table__", (char*)species->table, 1);
	add_property_long(object, "id", 0);
	add_property_long(object, "sitegroup", 0);
}

zval _midgard_getset_property(MidgardClass *species, 
							  zend_property_reference *property_reference,
							  zval *value)
{
	zval result, **ppresult;
	zval *object = property_reference->object;
	
	/* get the property name */
	zend_llist_element *element = property_reference->elements_list->head;
	zend_overloaded_element *property=(zend_overloaded_element *)element->data;
	char * propname = property->element.value.str.val;
	int proplen = property->element.value.str.len;

	INIT_ZVAL(result);

	if(value == NULL) {							/* get property */
/* DG: this should never happen now (check midgard.c MINIT function,
 * the get_property is set to NULL) */
		if(zend_hash_find(object->value.obj.properties, propname, proplen+1,
						(void **)&ppresult) == FAILURE) {
			php_error(E_WARNING,
						"Midgard: Property '%s' is not a member of %s",
						propname, species->name);
		} else {
			result = **ppresult;
			zval_copy_ctor(&result);
			return result;
		}

	} else if(strcasecmp("__table__", propname)) {	/* set r/w property */
		zend_hash_update(object->value.obj.properties, propname, proplen+1,
						&value, sizeof(zval *), NULL);
	} else {									/* cannot set ro property */
		php_error(E_WARNING,
						"Midgard: Write access to property '%s' forbidden",
						propname);
	}
	return result;
}

void php_midgard_delete(zval * return_value, const char *table, int id)
{
	CHECK_MGD;

	if (mgd_delete(mgd_handle(), table, id)) {
      RETURN_TRUE;
   }

   RETVAL_FALSE_BECAUSE(MGD_ERR_INTERNAL);

   /* EEH: TODO: log_error(
      "Midgard: delete of %s %d failed",
         table ? table : "<null class>", id);
   */
}

void php_midgard_delete_repligard(const char *table, int id)
{
	if (!mgd_rcfg())
		return;

	(void) mgd_delete_repligard(mgd_handle(), table, id);
}

void php_midgard_update(zval * return_value, const char *table,
			const char *fields, int id, ...)
{
   va_list args;
   CHECK_MGD;

   va_start(args, id);
	if (mgd_vupdate(mgd_handle(), table, id, fields, args)) {
      RETVAL_TRUE;
   }
   else {
	  RETVAL_FALSE_BECAUSE(MGD_ERR_INTERNAL);
      /* EEH: TODO: log_error(
         "Midgard: update of %s %d failed",
            table ? table : "<null class>", id);
      */
   }

   va_end(args);
}

void php_midgard_create(zval * return_value, const char *table,
			const char *fields, const char *values, ...)
{
	va_list args;
	int id;
	CHECK_MGD;

	va_start(args, values);
	id = mgd_vcreate(mgd_handle(), table, fields, values, args);
	va_end(args);

   if (!id) {
      RETURN_FALSE_BECAUSE(MGD_ERR_INTERNAL);

      /* EEH: TODO: log_error(
         "Midgard: create of %s failed",
            table ? table : "<null class>"); */
   }

	RETVAL_LONG(id);
}

void php_midgard_select(MidgardClass *species, zval * return_value,
			const char *fields, const char *tables,
			const char *where, const char *order, ...)
{
	va_list args;
	midgard_res *res;

	CHECK_MGD;

	va_start(args, order);
	res =
	   mgd_sitegroup_vselect(mgd_handle(), fields, tables, where, order,
				 args);
	va_end(args);
	if (res) {
		php_midgard_bless_oop(return_value, species);
		add_property_long(return_value, "N", mgd_rows(res));
		add_property_long(return_value, "__res__", (long) res);
	}
}

#if HAVE_MIDGARD_SITEGROUPS
void php_midgard_sitegroup_get(MidgardClass *species, zval * return_value,
               int grouped, const char *fields, const char *table, int id);
void php_midgard_get(MidgardClass *species, zval * return_value,
		     const char *fields, const char *table, int id)
{
	php_midgard_sitegroup_get(species, return_value, 1, fields, table, id);
}

void php_midgard_sitegroup_get(MidgardClass *species, zval * return_value,
               int grouped, const char *fields, const char *table, int id)
#else
void php_midgard_get(MidgardClass *species, zval * return_value,
		     const char *fields, const char *table, int id)
#endif
{
	midgard_res *res;
	int i;
	midgard_res *params = NULL;
	midgard_pool *pool = NULL;
	char *propname, *value=NULL;

	CHECK_MGD;

#if HAVE_MIDGARD_SITEGROUPS
	if (grouped)
		res = mgd_sitegroup_record(mgd_handle(), fields, table, id);
	else
		res = mgd_ungrouped_record(mgd_handle(), fields, table, id);
#else
	res = mgd_ungrouped_record(mgd_handle(), fields, table, id);
#endif
	if (res && mgd_fetch(res)) {
		php_midgard_bless_oop(return_value, species);

		params =
		   mgd_ungrouped_select(mgd_handle(), "domain,name,value",
					"record_extension",
					"tablename=$q AND oid=$d", NULL, table,
					id);
		if (params) {
			pool = mgd_alloc_pool();
			while (mgd_fetch(params)) {
				propname =
				   mgd_format(mgd_handle(), pool, "$s_$s",
					      mgd_colvalue(params, 0),
					      mgd_colvalue(params, 1));
				add_property_string(return_value, propname,
						    (char*)mgd_colvalue (params, 2), 1);
			}
		}

		for (i = 0; i < mgd_cols(res); i++) {
			if((value = (char *)mgd_colvalue(res, i)) == NULL ) {
				value = "";
			}
			add_property_string(return_value,
					    (char*)mgd_colname(res, i),
					    value, 1);
		}
	} else RETVAL_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if (res)
		mgd_release(res);
	if (params)
		mgd_release(params);
	if (pool)
		mgd_free_pool(pool);
}

/*
  midgard_get_by_name is responsible for returning topics and articles using
  their names instead ids. In other aspects it is equal to midgard_get.
  Additional parameters are:
  idfield - name of field used for id compare (should be 'topic' for article
            and 'up' for topic)
  parent_id      - id of idfield of seeking record (father's id for topic & article)
  name    - name of topic or article
  It allows to use equal names of articles and subtopics under different topics
*/

void php_midgard_get_by_name(MidgardClass *species, zval * return_value,
			     const char *fields, const char *table,
			     const char *idfield, int parent_id, const char *name)
{
	midgard_res *res;
	char * value=NULL;
	int i;
	CHECK_MGD;


	res =
	   mgd_record_by_name(mgd_handle(), fields, table, idfield,
         parent_id, name);
	if (res && mgd_fetch(res)) {
		php_midgard_bless_oop(return_value, species);
		for (i = 0; i < mgd_cols(res); i++) {
			if((value = (char *)mgd_colvalue(res, i)) == NULL ) {
				value = "";
			}
			add_property_string(return_value,
					    (char*)mgd_colname(res, i),
					    value, 1);
		}
	} else RETVAL_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	if (res)
		mgd_release(res);
}

void php_midgard_get_by_name2(MidgardClass *species, zval * return_value,
			      const char *fields, const char *table,
			      const char *firstfield, const char *first,
			      const char *secondfield, const char *second)
{
	midgard_res *res;
	char *value=NULL;
	int i;

	CHECK_MGD;

	res = mgd_record_by_name2(mgd_handle(), fields, table,
				  firstfield, first, secondfield, second);
	if (res && mgd_fetch(res)) {
		php_midgard_bless_oop(return_value, species);
		for (i = 0; i < mgd_cols(res); i++) {
			if((value = (char *)mgd_colvalue(res, i)) == NULL ) {
				value = "";
			}
			add_property_string(return_value,
					    (char*)mgd_colname(res, i),
					    value, 1);
		}
	} else RETVAL_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	if (res)
		mgd_release(res);
}

void php_midgard_get_by_name_only(MidgardClass *species, zval * return_value,
				  const char *fields, const char *table,
				  const char *name)
{
	midgard_res *res;
	int i;
	char *value=NULL;
	CHECK_MGD;

	res = mgd_record_by_name_only(mgd_handle(), fields, table, name);
	if (res && mgd_fetch(res)) {
		php_midgard_bless_oop(return_value, species);
		for (i = 0; i < mgd_cols(res); i++) {
			if((value = (char *)mgd_colvalue(res, i)) == NULL ) {
				value = "";
			}
			add_property_string(return_value,
					    (char*)mgd_colname(res, i),
					    value, 1);
		}
	} else RETVAL_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	if (res)
		mgd_release(res);
}

MGD_FUNCTION(ret_type, oop_guid_get, (type param))
{
	zval *self;
	zval **zv_table, **zv_id;
	midgard_pool *pool;
	char *guid;

	CHECK_MGD;

	if ((self = getThis()) == NULL) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
	}

	if (zend_hash_find
	    (self->value.obj.properties, "__table__", 10,
	     (void **) &zv_table) != SUCCESS) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

	if (zend_hash_find
	    (self->value.obj.properties, "id", 3,
	     (void **) &zv_id) !=
	    SUCCESS) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

	if (ZEND_NUM_ARGS() != 0) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(zv_id);
	convert_to_string_ex(zv_table);

	pool = mgd_pool(mgd_handle());
	guid =
	   mgd_repligard_guid(mgd_handle(), pool, (*zv_table)->value.str.val,
			      (*zv_id)->value.lval);
	if (guid) {
		RETVAL_STRING(guid, 1);
		mgd_free_from_pool(pool, guid);
	}
	else {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	}
}

MGD_FUNCTION(ret_type, oop_list_fetch, (type param))
{
	zval *self;
	zval **key;
	midgard_res *res;
   int i;

	CHECK_MGD;
	RETVAL_FALSE;

	if ((self = getThis()) == NULL) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

	if (zend_hash_find(self->value.obj.properties, "__res__", 8, (void
								      **) &key)
	    != SUCCESS) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }

   if ((res = (midgard_res *) (*key)->value.lval) == NULL) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }

   if (mgd_fetch(res)) {
      for (i = 0; i < mgd_cols(res); i++)
         add_property_string(self, (char*)mgd_colname(res, i),
            (char*)mgd_colvalue(res, i), 1);
      RETVAL_TRUE;
   } else {
      mgd_release(res);
      zend_hash_del(self->value.obj.properties, "__res__", 8);

      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }
}

void php_midgard_get_object(zval *return_value, int table, int id)
{
#if HAV_MIDGARD_SITEGROUPS
#define MGD_GET_OBJECT_SITEGROUP_FIELD ",sitegroup"
#else
#define MGD_GET_OBJECT_SITEGROUP_FIELD ""
#endif

   switch (table) {
      case MIDGARD_OBJECT_ARTICLE:
         php_midgard_get(&MidgardArticle, return_value,
            "id,up,topic,name,title,abstract,content,author,"
               "Date_format(created,'%d.%m.%Y') AS date,"
               "Date_format(created,'%D %b. %Y') AS adate,"
               "Date_format(created,'%D %M %Y') AS aldate,"
               "extra1,extra2,extra3,article.score,type,"
               "Unix_Timestamp(created) AS created,creator,"
               "Unix_Timestamp(revised) AS revised,revisor,revision,"
               "Unix_Timestamp(approved) AS approved,approver,"
               "Unix_Timestamp(locked) AS locked,locker,"
               "url,icon,view,print,"
               CALENDAR_FIELDS
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "article", id);
         break;

      case MIDGARD_OBJECT_BLOBS:
         php_midgard_get(&MidgardAttachment, return_value,
            "id,name,title,mimetype,score,author,created,ptable,pid"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
			   "blobs", id);
         break;

      case MIDGARD_OBJECT_ELEMENT:
         php_midgard_get(&MidgardElement, return_value,
            "id,style,name,value" MGD_GET_OBJECT_SITEGROUP_FIELD,
            "element", id);
         break;

      case MIDGARD_OBJECT_EVENT:
         php_midgard_get(&MidgardEvent, return_value,
            "id,up,start,end,title,description,"
               "type,extra,owner,creator,created,revisor,revised,revision,busy"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "event", id);
         break;

      case MIDGARD_OBJECT_EVENTMEMBER:
         php_midgard_get(&MidgardEventMember, return_value, "id,eid,uid,extra"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "eventmember", id);
         break;

      case MIDGARD_OBJECT_FILE:
         php_midgard_get(&MidgardFile, return_value,
            "id,article,type,name,content,size,md5"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "file", id);
         break;

      case MIDGARD_OBJECT_GRP:
         php_midgard_get(&MidgardGroup, return_value, 
            "id,name,official," ADDRESS_FIELDS ","
               GROUP_HOMEPAGE_FIELDS "," GROUP_EMAIL_FIELDS ","
					"extra,owner"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "grp", id);
         break;

      case MIDGARD_OBJECT_HOST:
         php_midgard_get(&MidgardHost, return_value,
				"id,name,port,online,root,style,info&1 AS auth,owner,prefix,"
               HOSTNAME_FIELD
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
				"host", id);
         break;

      case MIDGARD_OBJECT_IMAGE:
         php_midgard_get(&MidgardImage, return_value,
            "id,src,x,y,info&1=1 AS offline,"
               "If(info&1,Concat('<img src=\"/img/',src,"
               "'\" width=\"',x,'\" height=\"',y,'\">'),'') AS img"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
               "image", id);
         break;

      case MIDGARD_OBJECT_MEMBER:
         php_midgard_get(&MidgardMember, return_value,
            "id,gid,uid,extra" MGD_GET_OBJECT_SITEGROUP_FIELD,
            "member", id);
         break;

      case MIDGARD_OBJECT_PAGE:
         php_midgard_get(&MidgardPage, return_value,
            "id,up,name,style,title,changed,content,author,"
               "info&1=1 AS auth,info&2=2 AS active"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "page", id);
         break;

      case MIDGARD_OBJECT_PAGEELEMENT:
         php_midgard_get(&MidgardPageElement, return_value,
            "id,page,name,value,info&1 AS inherit"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "pageelement", id);
         break;

#if HAVE_MIDGARD_PAGELINKS
      case MIDGARD_OBJECT_PAGELINK:
         php_midgard_get(&MidgardPagelink, return_value,
            "id,up,name,target,grp,owner"
		         MGD_GET_OBJECT_SITEGROUP_FIELD,
            "pagelink", id);
         break;
#endif

      case MIDGARD_OBJECT_PERSON:
         if (isuserowner(id))
            php_midgard_get(&MidgardPerson, return_value,
               "id," NAME_FIELDS ","
                  "If(Left(password,2)='**',Substring(password,3),'')"
                  " AS password,"
                  ADDRESS_FIELDS "," PHONE_FIELDS ","
                  HOMEPAGE_FIELDS "," EMAIL_FIELDS ","
                  "Date_format(birthdate,'%d.%m.%Y') AS birthdate,extra,"
                  "img,topic,department,office,pgpkey," PUBLIC_FIELDS
		            MGD_GET_OBJECT_SITEGROUP_FIELD,
               "person", id);
         else
            php_midgard_get(&MidgardPerson, return_value,
               "id," NAME_FIELDS ",'' AS password,"
                  "If(info&2," ADDRESS_FIELD ",'') AS address,"
                  PUBLIC_FIELD(2,street) ","
                  PUBLIC_FIELD(2,postcode) ","
                  PUBLIC_FIELD(2,city) ","
                  "If(info&4," PHONE_FIELD ",'') AS phone,"
                  PUBLIC_FIELD(4,handphone) ","
                  PUBLIC_FIELD(4,homephone) ","
                  PUBLIC_FIELD(4,workphone) ","
                  "If(info&8," HOMEPAGE_FIELD ",'') AS homepagelink,"
                  PUBLIC_FIELD(8,homepage) ","
                  "If(info&16," EMAIL_FIELD ",'') AS emaillink,"
                  PUBLIC_FIELD(16,email) ","
                  "'' AS birthdate," PUBLIC_FIELD(32,extra) ","
                  PUBLIC_FIELD(32,img) ",topic,department,office,pgpkey,"
                  PUBLIC_FIELDS
		            MGD_GET_OBJECT_SITEGROUP_FIELD,
               "person", id);
         break;

      case MIDGARD_OBJECT_PREFERENCE:
         php_midgard_get(&MidgardPreferences, return_value,
            "id,uid,domain,name,value" MGD_GET_OBJECT_SITEGROUP_FIELD,
            "preference", id);
         break;

#if HAVE_MIDGARD_SITEGROUPS
      case MIDGARD_OBJECT_SITEGROUP:
         php_midgard_sitegroup_get(&MidgardSitegroup, return_value, 0, "*",
            "sitegroup", id);
         break;
#endif

      case MIDGARD_OBJECT_SNIPPET:
         php_midgard_get(&MidgardSnippet, return_value,
            "id,up,name,code,doc,author,creator,created,revisor,"
               "revised,revision" MGD_GET_OBJECT_SITEGROUP_FIELD,
            "snippet", id);
         break;

      case MIDGARD_OBJECT_SNIPPETDIR:
         php_midgard_get(&MidgardSnippetdir, return_value, "id,up,name,description,owner"
               MGD_GET_OBJECT_SITEGROUP_FIELD,
            "snippetdir", id);
         break;

      case MIDGARD_OBJECT_STYLE:
         php_midgard_get(&MidgardStyle, return_value, "id,up,name,owner"
               MGD_GET_OBJECT_SITEGROUP_FIELD,
            "style", id);
         break;

      case MIDGARD_OBJECT_TOPIC:
         php_midgard_get(&MidgardTopic, return_value,
            "id,up,score,name,description,extra,owner,code,"
               "creator,Unix_timestamp(created) as created,"
               "revisor,Unix_timestamp(revised) as revised,revision"
               MGD_GET_OBJECT_SITEGROUP_FIELD,
            "topic", id);
         break;

      /* EEH: These are not handled */
      case MIDGARD_OBJECT_REPLIGARD:
      case MIDGARD_OBJECT_RECORD_EXTENSION:
      case MIDGARD_OBJECT_HISTORY:
      default:
         RETURN_FALSE_BECAUSE(MGD_ERR_INTERNAL);
   }
}

MGD_FUNCTION(ret_type, get_object_by_guid, (type param))
{
   zval **guid;
   midgard_res *res;
   long table, id;

   if (ZEND_NUM_ARGS() != 1 || zend_get_parameters_ex(1, &guid) != SUCCESS) {
      WRONG_PARAM_COUNT;
   }

   if ((*guid)->type != IS_STRING) { RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS); }

   res = mgd_sitegroup_select(mgd_handle(), "realm,id", "repligard",
            "guid=$q", NULL, (*guid)->value.str.val);

   if (!res || !mgd_fetch(res)) {
      if (res) mgd_release(res);
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }

   table = mgd_lookup_table_id(mgd_colvalue(res, 0));
   id = atoi(mgd_colvalue(res, 1));

   mgd_release(res);

   php_midgard_get_object(return_value, table, id);
}

MidgardClassPtr MidgardClasses [] = {
   &MidgardArticle,
   &MidgardAttachment,
   &MidgardElement,
   &MidgardEvent,
   &MidgardEventMember,
   &MidgardFile,
   &MidgardGroup,
   &MidgardHost,
   &MidgardImage,
   &MidgardMember,
   &MidgardPage,
   &MidgardPageElement,
   &MidgardParameter,
   &MidgardPerson,
   &MidgardPreferences,
#if HAVE_MIDGARD_SITEGROUPS
   &MidgardSitegroup,
#endif
   &MidgardSnippet,
   &MidgardSnippetdir,
   &MidgardStyle,
   &MidgardTopic,
   NULL
};
