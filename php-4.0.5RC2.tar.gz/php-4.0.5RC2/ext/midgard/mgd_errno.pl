#!/usr/bin/perl
#Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
#Copyright (C) 2000 The Midgard Project ry
#Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>
#
#This program is free software; you can redistribute it and/or modify it
#under the terms of the GNU Lesser General Public License as published
#by the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

$commonprefix = "MGD_ERR_";

$errcodes=<<EOERRS;

OK
ERROR						Error
ACCESS_DENIED			Access denied
SITEGROUP_VIOLATION	Resource link crosses sitegroup borders
NOT_OBJECT				Object has no ID
NOT_EXISTS				Object does not exist
NO_MEM					Can't allocate memory
INVALID_NAME			Username has invalid characters
DUPLICATE				Name exists
HAS_DEPENDANTS			Resource has dependants
RANGE						Date range error
NOT_CONNECTED        Not connected to the Midgard database
SG_NOTFOUND          Sitegroup not found
INVALID_OBJECT       Object doesn't have the expected set of properties

INTERNAL					Internal error

EOERRS

###################################################################

($basename) = ($0 =~ /(.*)\.pl/);

$basename || die "$0 must end in .pl\n";

open H, ">$basename.h";
open C, ">$basename.c";

print H "#ifndef MGD_ERRNO_H\n#define MGD_ERRNO_H\n\n";
print C "#include \"mgd_errno.h\"\n";

foreach (split(/\n/, $errcodes)) {
	($name, $comment) = /([A-Z][_A-Z0-9]*)\t+(.*)/;
	if (!$name) {
		($name, $value) = /([A-Z][_A-Z0-9]*)/;
	}
	$name || next;

	$comment =~ s/"/\\"/;

	$name = "$commonprefix$name";

	if (! $comment ) { $comment = $name; }

	push @names, $name;
	$defines{$name} = -$#names;
	$comments{$name} = $comment;
}

foreach (@names) {
	print H "#define $_ $defines{$_}\n";
}
print H "\n";

print H "typedef struct { char *name; int value; } mgd_errno_codename_def;\n";
print H "extern mgd_errno_codename_def mgd_errno_codename[];\n";

print C "mgd_errno_codename_def mgd_errno_codename[]= {\n";
foreach (@names) {
	print C "\t{\t\"$_\",\t$_\t},\n";
}
print C "\t{\t(void*)0,\t0\t}\n};\n\n";

print H "char* mgd_errstr(int errcode);\n";
print C "char* mgd_errstr(int errcode)\n{\n";
print C "\tswitch (errcode) {\n";
foreach (@names) {
	print C "\t\tcase $_: return \"$comments{$_}\";\n";
}
print C "\t}\n\n";
print C "\treturn \"Unknow error code\";\n}\n";

print H "\n#endif\n";
