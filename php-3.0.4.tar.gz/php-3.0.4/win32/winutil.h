extern char *php3_win_err(void);
