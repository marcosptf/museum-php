#ifndef _PHP_CDB_H
#define _PHP_CDB_H

#if DBA_CDB

#include "php_dba.h"

DBA_FUNCS(cdb);

#endif

#endif
