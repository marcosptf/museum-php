new __TestParser2 string(13) "__testparser2"
setInputFile resource(2) of type 2
parse <ROOT><![CDATA[foo]]></ROOT>
bool(true)
