new __TestParser3 string(13) "__testparser3"
fopen resource(2) of type 2
setInput bool(true)
parse <ROOT><![CDATA[foo]]></ROOT>
bool(true)
