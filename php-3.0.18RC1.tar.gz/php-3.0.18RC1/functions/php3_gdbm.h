#ifndef _PHP3_GDBM_H
#define _PHP3_GDBM_H

#if DBA_GDBM

#include "php3_dba.h"

DBA_FUNCS(gdbm);

#endif

#endif
