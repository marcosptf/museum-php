#ifndef _PHP3_NDBM_H
#define _PHP3_NDBM_H

#if DBA_NDBM

#include "php3_dba.h"

DBA_FUNCS(ndbm);

#endif

#endif
