#ifndef _PHP3_CDB_H
#define _PHP3_CDB_H

#if DBA_CDB

#include "php3_dba.h"

DBA_FUNCS(cdb);

#endif

#endif
