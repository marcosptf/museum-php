#ifndef _PHP3_DB2_H
#define _PHP3_DB2_H

#if DBA_DB2

#include "php3_dba.h"

DBA_FUNCS(db2);

#endif

#endif
