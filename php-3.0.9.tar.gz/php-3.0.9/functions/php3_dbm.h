#ifndef _PHP3_DBM_H
#define _PHP3_DBM_H

#if DBA_DBM

#include "php3_dba.h"

DBA_FUNCS(dbm);

#endif

#endif
