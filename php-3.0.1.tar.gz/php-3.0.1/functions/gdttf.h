char *gdttf(gdImage *im, int *brect, int fgcolor, char *fontname, 
	double ptsize, double angle, int x, int y, int *string, int len);
