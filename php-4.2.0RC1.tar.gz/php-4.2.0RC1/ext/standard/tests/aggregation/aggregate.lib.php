<?php

class simple {
	var $simple_prop = 100;

	function simple()
	{
		print "I'm alive!\n";
	}
}

class helper {
	var $my_prop = 5;
	var $your_prop = array('init' => PHP_VERSION);
	var $our_prop = '****';
	var $_priv_prop = null;

	function helper()
	{
		print "just trying to help\n";
	}

	function do_this()
	{
		print "I'm helping!\n";
	}

	function do_that()
	{
		print "I'm aggregating!\n";
	}

	function just_another_method()
	{
		print "yep, that's me\n";
	}

	function _private()
	{
		print "Don't touch me!\n";
	}

	function __wakeup()
	{
	}
}

class mixin {
	var $simple_prop = true;
	var $mix = true;

	function mix_it()
	{
		print "mixing\n";
	}
}

class moby {
	function mix_it()
	{
		print "I'm redundant!\n";
	}
}

?>
