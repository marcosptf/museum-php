/* $Id: mgd_oop.h,v 1.5 2001/02/28 01:00:31 davidg Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef MGD_OOP_H
#define MGD_OOP_H

#include <zend.h>
#include <midgard/tablenames.h>

MGD_FUNCTION(ret_type, oop_parameter, (type param));
MGD_FUNCTION(ret_type, oop_parameter_list, (type param));
MGD_FUNCTION(ret_type, oop_parameter_search, (type param));

MGD_FUNCTION(ret_type, get_attachment, (type param));
MGD_FUNCTION(ret_type, oop_attachment_create, (type param));
MGD_FUNCTION(ret_type, oop_attachment_list, (type param));
MGD_FUNCTION(ret_type, open_attachment, (type param));
MGD_FUNCTION(ret_type, serve_attachment, (type param));
MGD_FUNCTION(ret_type, delete_attachment, (type param));
MGD_FUNCTION(ret_type, update_attachment, (type param));

MGD_FUNCTION(ret_type, oop_guid_get, (type param));

MGD_FUNCTION(ret_type, oop_list_fetch, (type param));

// DG: are all these oop_xxxx_create functions actually exist ?
MGD_FUNCTION(ret_type, oop_element_create, (type param));
MGD_FUNCTION(ret_type, delete_element, (type param));
MGD_FUNCTION(ret_type, update_element, (type param));

MGD_FUNCTION(ret_type, oop_group_create, (type param));
MGD_FUNCTION(ret_type, delete_group, (type param));
MGD_FUNCTION(ret_type, update_group, (type param));

MGD_FUNCTION(ret_type, oop_article_create, (type param));
MGD_FUNCTION(ret_type, oop_article_score, (type param));
MGD_FUNCTION(ret_type, delete_article, (type param));
MGD_FUNCTION(ret_type, update_article, (type param));

MGD_FUNCTION(ret_type, oop_topic_create, (type param));
MGD_FUNCTION(ret_type, oop_topic_score, (type param));
MGD_FUNCTION(ret_type, delete_topic, (type param));
MGD_FUNCTION(ret_type, update_topic, (type param));

MGD_FUNCTION(ret_type, oop_file_create, (type param));
MGD_FUNCTION(ret_type, delete_file, (type param));
MGD_FUNCTION(ret_type, update_file, (type param));

MGD_FUNCTION(ret_type, oop_host_create, (type param));
MGD_FUNCTION(ret_type, delete_host, (type param));
MGD_FUNCTION(ret_type, update_host, (type param));

MGD_FUNCTION(ret_type, oop_image_create, (type param));
MGD_FUNCTION(ret_type, delete_image, (type param));
MGD_FUNCTION(ret_type, update_image, (type param));

MGD_FUNCTION(ret_type, oop_member_create, (type param));
MGD_FUNCTION(ret_type, delete_member, (type param));
MGD_FUNCTION(ret_type, update_member, (type param));

MGD_FUNCTION(ret_type, oop_person_create, (type param));
MGD_FUNCTION(ret_type, delete_person, (type param));
MGD_FUNCTION(ret_type, update_person, (type param));

MGD_FUNCTION(ret_type, oop_preference_create, (type param));
MGD_FUNCTION(ret_type, delete_preference, (type param));
MGD_FUNCTION(ret_type, update_preference, (type param));

MGD_FUNCTION(ret_type, oop_page_create, (type param));
MGD_FUNCTION(ret_type, delete_page, (type param));
MGD_FUNCTION(ret_type, update_page, (type param));

#if HAVE_MIDGARD_PAGELINKS
MGD_FUNCTION(ret_type, oop_pagelink_create, (type param));
MGD_FUNCTION(ret_type, delete_pagelink, (type param));
MGD_FUNCTION(ret_type, update_pagelink, (type param));
#endif

MGD_FUNCTION(ret_type, oop_event_create, (type param));
MGD_FUNCTION(ret_type, delete_event, (type param));
MGD_FUNCTION(ret_type, update_event, (type param));
MGD_FUNCTION(ret_type, oop_event_member_create, (type param));
MGD_FUNCTION(ret_type, delete_event_member, (type param));
MGD_FUNCTION(ret_type, update_event_member, (type param));

#if HAVE_MIDGARD_SITEGROUPS
MGD_FUNCTION(ret_type, oop_sitegroup_set, (type param));
MGD_FUNCTION(ret_type, oop_sitegroup_get, (type param));

MGD_FUNCTION(ret_type, create_sitegroup, (type param));
MGD_FUNCTION(ret_type, delete_sitegroup, (type param));
MGD_FUNCTION(ret_type, update_sitegroup, (type param));
#endif

MGD_FUNCTION(ret_type, oop_style_create, (type param));
MGD_FUNCTION(ret_type, delete_style, (type param));
MGD_FUNCTION(ret_type, update_style, (type param));

MGD_FUNCTION(ret_type, oop_pageelement_create, (type param));
MGD_FUNCTION(ret_type, delete_pageelement, (type param));
MGD_FUNCTION(ret_type, update_pageelement, (type param));

MGD_FUNCTION(ret_type, oop_snippetdir_create, (type param));
MGD_FUNCTION(ret_type, delete_snippetdir, (type param));
MGD_FUNCTION(ret_type, update_snippetdir, (type param));

MGD_FUNCTION(ret_type, oop_snippet_create, (type param));
MGD_FUNCTION(ret_type, delete_snippet, (type param));
MGD_FUNCTION(ret_type, update_snippet, (type param));

MGD_FUNCTION(ret_type, get_object_by_guid, (type param));

typedef struct {
	int type;
	char * name;
/* default value ? */
} MidgardProperty;

typedef MidgardProperty* MidgardPropertyPtr;

typedef struct {
   const char *name;
   const char *table;
   zend_function_entry *methods;
   zend_class_entry class_entry;
   void (*function_call)(INTERNAL_FUNCTION_PARAMETERS,
		         		zend_property_reference *property_reference);
   zval (*get_property)(zend_property_reference *property_reference);
   int (*set_property)(zend_property_reference *property_reference,
						zval *value);
   MidgardProperty *properties;
   zend_class_entry *entry_ptr;
} MidgardClass;

typedef MidgardClass* MidgardClassPtr;
extern MidgardClassPtr MidgardClasses[];

void mgd_object_init(zval *obj, ...);
void php_midgard_bless(zval *object, MidgardClass *species);
void php_midgard_ctor(zval *object, MidgardClass *species);
void php_midgard_delete(zval * return_value, const char *table, int id);
void php_midgard_delete_repligard(const char *table, int id);
void php_midgard_update(zval * return_value, const char *table,
   const char *fields, int id, ...);
void php_midgard_create(zval * return_value, const char *table,
   const char *fields, const char *values, ...);
void php_midgard_select(MidgardClass *species, zval * return_value,
   const char *fields, const char *tables,
   const char *where, const char *order, ...);
#if HAVE_MIDGARD_SITEGROUPS
void php_midgard_sitegroup_get(MidgardClass *species,
               zval * return_value, int grouped,
               const char *fields, const char *table, int id);
#endif
void php_midgard_get(MidgardClass *species, zval * return_value,
   const char *fields, const char *table, int id);
void php_midgard_get_by_name(MidgardClass *species, zval * return_value,
   const char *fields, const char *table,
   const char *idfield, int parent_id, const char *name);
void php_midgard_get_by_name2(MidgardClass *species, zval * return_value,
   const char *fields, const char *table,
   const char *firstfield, const char *first,
   const char *secondfield, const char *second);
void php_midgard_get_by_name_only(MidgardClass *species, zval * return_value,
   const char *fields, const char *table, const char *name);
zval _midgard_getset_property(MidgardClass *Class,
		zend_property_reference *property_reference,
						zval *value);

void php_midgard_get_object(zval *return_value, int table, int id);

extern MidgardClass MidgardArticle;
extern MidgardClass MidgardAttachment;
extern MidgardClass MidgardElement;
extern MidgardClass MidgardEvent;
extern MidgardClass MidgardEventMember;
extern MidgardClass MidgardFile;
extern MidgardClass MidgardGroup;
extern MidgardClass MidgardHost;
extern MidgardClass MidgardImage;
extern MidgardClass MidgardMember;
extern MidgardClass MidgardPage;
extern MidgardClass MidgardPageElement;
extern MidgardClass MidgardParameter;
extern MidgardClass MidgardPerson;
extern MidgardClass MidgardPreferences;
extern MidgardClass MidgardSnippet;
extern MidgardClass MidgardSnippetdir;
extern MidgardClass MidgardStyle;
extern MidgardClass MidgardTopic;
#if HAVE_MIDGARD_SITEGROUPS
extern MidgardClass MidgardSitegroup;
#endif
#if HAVE_MIDGARD_PAGELINKS
extern MidgardClass MidgardPagelink;
#endif

/* OOP_SITEGROUP_METHODS include also method for
   gathering GUID for given object
*/
#if HAVE_MIDGARD_SITEGROUPS
#define MIDGARD_OOP_SITEGROUP_METHODS \
	PHP_FALIAS(setsitegroup,      mgd_oop_sitegroup_set, NULL) \
	PHP_FALIAS(getsitegroup,      mgd_oop_sitegroup_get, NULL) \
	PHP_FALIAS(guid,              mgd_oop_guid_get,          NULL)
#else
#define MIDGARD_OOP_SITEGROUP_METHODS \
	PHP_FALIAS(guid,              mgd_oop_guid_get,          NULL)
#endif

#define MIDGARD_OOP_ATTACHMENT_METHODS \
   PHP_FALIAS(getattachment,     mgd_get_attachment,        NULL) \
   PHP_FALIAS(createattachment,  mgd_oop_attachment_create, NULL) \
   PHP_FALIAS(listattachments,   mgd_oop_attachment_list,   NULL) \
   PHP_FALIAS(openattachment,    mgd_open_attachment,       NULL) \
   PHP_FALIAS(serveattachment,   mgd_serve_attachment,      NULL) \
   PHP_FALIAS(deleteattachment,  mgd_delete_attachment,     NULL) \
   PHP_FALIAS(updateattachment,  mgd_update_attachment,     NULL)

#define MIDGARD_OOP_PARAMETER_METHODS \
	PHP_FALIAS(parameter,         mgd_oop_parameter,         NULL) \
	PHP_FALIAS(searchparameters,  mgd_oop_parameter_search,  NULL) \
	PHP_FALIAS(listparameters,    mgd_oop_parameter_list,    NULL)

#define MIDGARD_CLASS(name,type) \
MIDGARD_HANDLERS_DECL(type) \
static zend_function_entry name ## Methods[] = \
   { \
      PHP_FALIAS(midgard # type,   mgd_ctor_ ## type ,   NULL) \
      PHP_FALIAS(create,   mgd_create_ ## type ,   NULL) \
      PHP_FALIAS(update,   mgd_update_ ## type ,   NULL) \
      PHP_FALIAS(delete,   mgd_delete_ ## type ,   NULL) \
      PHP_FALIAS(fetch,    mgd_oop_list_fetch,     NULL) \
      MIDGARD_OOP_ATTACHMENT_METHODS \
      MIDGARD_OOP_SITEGROUP_METHODS \
      MIDGARD_OOP_PARAMETER_METHODS \
      {NULL, NULL, NULL} \
   }; \
MidgardClass name = { \
   #name, \
   #type, \
   name ## Methods, \
   {}, \
   mgd_ ## type ## _call_function_handler, \
   mgd_ ## type ## _get_property_handler, \
   mgd_ ## type ## _set_property_handler, \
   name ## Properties, \
   NULL \
}; \
MIDGARD_HANDLERS(name, type)

#define MIDGARD_HANDLERS_DECL(type) \
void mgd_ ## type ## _call_function_handler(INTERNAL_FUNCTION_PARAMETERS, \
		         		zend_property_reference *property_reference); \
zval mgd_ ## type ## _get_property_handler(zend_property_reference *property_reference); \
int mgd_ ## type ## _set_property_handler(zend_property_reference *property_reference, \
						zval *value); \
MGD_FUNCTION(ret_type, ctor_ ## type, (type param));

#define MIDGARD_HANDLERS(name, type) \
void mgd_ ## type ## _call_function_handler(INTERNAL_FUNCTION_PARAMETERS, \
		         		zend_property_reference *property_reference) \
{ \
	zval *object = property_reference->object; \
	zend_overloaded_element *function_name = (zend_overloaded_element *) \
						property_reference->elements_list->tail->data; \
 \
/*	int arg_count = 0; \
	zval **arguments = NULL; \
	 \
	if((arg_count = ZEND_NUM_ARGS()) > 0) { \
		arguments = (pval **) emalloc(sizeof(pval *)*arg_count); \
	} */ \
	RETVAL_TRUE; \
 \
	CHECK_MGD; \
 \
/*	getParametersArray(ht, arg_count, arguments); */ \
	/* if the constructor is called */ \
	if (!strcasecmp( #name ,function_name->element.value.str.val)) { \
	/* construct a Midgard object */ \
		pval *object_handle; \
		php_midgard_bless(object, &name); \
		ALLOC_ZVAL(object_handle); \
		*object_handle = *return_value; \
		pval_copy_constructor(object_handle); \
		INIT_PZVAL(object_handle); \
/*		zend_hash_index_update(object->value.obj.properties, 0, &object_handle, sizeof(pval *), NULL); */ \
 \
	} else { \
		zend_function_entry * methods = name ## Methods; \
		int ok = 0; \
		while(methods && methods->fname) { \
			if(!strcmp(function_name->element.value.str.val, methods->fname)) { \
				methods->handler(INTERNAL_FUNCTION_PARAM_PASSTHRU); \
				ok = 1; \
				break; \
			} \
			methods++; \
		} \
		if(!ok) { \
			/* pval_destructor(&function_name->element); */ \
			php_error(E_ERROR, \
						"Midgard: Method '%s' is not a member of " #name, \
						function_name->element.value.str.val); \
		} \
/*		PHP_FN(manage function aliases here)(INTERNAL_FUNCTION_PARAM_PASSTHRU); */ \
	} \
/*	efree(arguments); */ \
	pval_destructor(&function_name->element); \
} \
 \
zval mgd_ ## type ## _get_property_handler(zend_property_reference *property_reference) \
{ \
	zval result; \
	result = _midgard_getset_property(&name, property_reference, NULL); \
	return result; \
} \
 \
int mgd_ ## type ## _set_property_handler(zend_property_reference *property_reference, \
						zval *value) \
{ \
	zval result; \
	result = _midgard_getset_property(&name, property_reference, value); \
	/* TODO: test result to know if we return SUCCESS or FAILURE */ \
	return SUCCESS; \
} \
MGD_FUNCTION(void, ctor_ ## type, (void)) \
{ \
	if ((return_value = getThis()) == NULL) { \
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT); \
	} \
	php_midgard_ctor(return_value, &name); \
}

#endif
