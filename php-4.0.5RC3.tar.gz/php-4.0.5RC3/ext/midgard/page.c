/* $Id: page.c,v 1.12 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, is_page_owner, (type param))
{
    IDINIT;
    CHECK_MGD;
    RETVAL_LONG(ispageowner(id));
}

MGD_FUNCTION(ret_type, copy_page, (type param))
{
    zval **id, **root; int id_r;

    RETVAL_FALSE;
	CHECK_MGD;
    if (ZEND_NUM_ARGS() != 2
	|| zend_get_parameters_ex(2, &id, &root) != SUCCESS)
	WRONG_PARAM_COUNT;
    convert_to_long_ex(id);
    convert_to_long_ex(root);

#if HAVE_MIDGARD_SITEGROUPS
	/* root must be in same SG or be 0 */
	if ((*root)->value.lval != 0 && !mgd_exists_bool(mgd_handle(), "page src, page tgt",
										"src.id=$d AND tgt.id=$d"
										" AND (src.sitegroup=tgt.sitegroup"
											" OR src.sitegroup=0"
											" OR tgt.sitegroup=0)",
										(*id)->value.lval,(*root)->value.lval)) RETURN_FALSE_BECAUSE(MGD_ERR_SITEGROUP_VIOLATION);
#endif

    id_r = mgd_copy_page(mgd_handle(),  (*id)->value.lval);
    if(id_r) {
      php_midgard_update(return_value, "page", "up=$i", id_r, (*root)->value.lval);
      PHP_UPDATE_REPLIGARD("page",id_r);
    }
	RETVAL_LONG(id_r);
}

MGD_FUNCTION(ret_type, list_pages, (type param))
{
    IDINIT;
	CHECK_MGD;
    php_midgard_select(&MidgardPage, return_value, "page.id AS id,name,style,title,changed,author,"
	       NAME_FIELD " AS authorname"
#if HAVE_MIDGARD_SITEGROUPS
         ",page.sitegroup"
#endif
         , "page,person",
	       "up=$d AND person.id=page.author", "name", id);
}

MGD_FUNCTION(ret_type, is_in_page_tree, (type param))
{
    zval **root, **page;

    RETVAL_FALSE;
	CHECK_MGD;
    if (ZEND_NUM_ARGS() != 2
	|| zend_get_parameters_ex(2, &root, &page) != SUCCESS)
	WRONG_PARAM_COUNT;
    convert_to_long_ex(root);
    convert_to_long_ex(page);

	if((*page)->value.lval == 0 || /* useless to waste time if page=0 */
				!mgd_exists_id(mgd_handle(),
						"page", "id=$d",
						(*page)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	if ((*root)->value.lval == 0)
		RETURN_TRUE; /* always true if root=0 */
	if(!mgd_exists_id(mgd_handle(), "page", "id=$d", (*root)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

    if(mgd_is_in_tree(mgd_handle(), "page", "up",
							(*root)->value.lval, (*page)->value.lval))
		RETURN_TRUE;
}

MGD_FUNCTION(ret_type, get_page, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
		case 0:
		php_midgard_bless(return_value, &MidgardPage);
		mgd_object_init(return_value, "up", "name", "style", "title", "content", "author", "auth", "active", NULL);
			return;
		case 1:
			if (zend_get_parameters_ex(1, &id) == SUCCESS) {
				convert_to_long_ex(id);
				break;
			} /* else fall through */
		default:
			WRONG_PARAM_COUNT;
	}

   php_midgard_get_object(return_value, MIDGARD_OBJECT_PAGE, (*id)->value.lval);
}

MGD_FUNCTION(ret_type, get_page_by_name, (type param))
{
    zval **root, **page;
	CHECK_MGD;
    if (ZEND_NUM_ARGS() != 2
	|| zend_get_parameters_ex(2, &root, &page) != SUCCESS)
	WRONG_PARAM_COUNT;
    convert_to_long_ex(root);
    convert_to_string_ex(page);

    php_midgard_get_by_name(&MidgardPage, return_value, "id,up,name,style,title,changed,content,author,"
	    "info&1=1 AS auth,info&2=2 AS active",
	    "page", "up", (*root)->value.lval, (*page)->value.str.val);
}

MGD_FUNCTION(ret_type, create_page, (type param))
{
	zval **up, **name, **style, **title, **content, **author, **auth, **active, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "up", up)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "style", style)
		    || !MGD_PROPFIND(self, "title", title)
		    || !MGD_PROPFIND(self, "content", content)
		    || !MGD_PROPFIND(self, "author", author)
		    || !MGD_PROPFIND(self, "auth", auth)
		    || !MGD_PROPFIND(self, "active", active)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 8
		    || zend_get_parameters_ex(8, &up, &name, &style, &title,
				     &content, &author, &auth,
				     &active) == FAILURE) WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(up);
	convert_to_string_ex(name);
	convert_to_long_ex(style);
	convert_to_string_ex(title);
	convert_to_string_ex(content);
	convert_to_long_ex(author);
	convert_to_long_ex(auth);
	convert_to_long_ex(active);

	if (!ispageowner((*up)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	if ((*up)->value.lval != 0
	      && mgd_exists_id(mgd_handle(), "page", "up=$d AND name=$q",
			     (*up)->value.lval, (*name)->value.str.val))
		RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

	if ((*up)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "page", "id=$d", (*up)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if ((*style)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "style", "id=$d", (*style)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	
	if (!mgd_exists_id(mgd_handle(), "person", "id=$d", (*author)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	php_midgard_create(return_value, "page",
			   "up,name,style,title,changed,content,author,info",
			   "$d,$q,$d,$q,Curdate(),$q,$d,$d",
			   (*up)->value.lval, (*name)->value.str.val,
			   (*style)->value.lval, (*title)->value.str.val,
			   (*content)->value.str.val, (*author)->value.lval,
			   ((*auth)->value.lval == 1) | ((*active)->value.lval ==
						      1) << 1);

	PHP_CREATE_REPLIGARD("page", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_page, (type param))
{
	zval **id, **name, **style, **title, **content, **author, **auth, **active, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "id", id)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "style", style)
		    || !MGD_PROPFIND(self, "title", title)
		    || !MGD_PROPFIND(self, "content", content)
		    || !MGD_PROPFIND(self, "author", author)
		    || !MGD_PROPFIND(self, "auth", auth)
		    || !MGD_PROPFIND(self, "active", active)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 8
		    || zend_get_parameters_ex(8, &id, &name, &style, &title,
				     &content, &author, &auth,
				     &active) == FAILURE) WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(id);
	convert_to_string_ex(name);
	convert_to_long_ex(style);
	convert_to_string_ex(title);
	convert_to_string_ex(content);
	convert_to_long_ex(author);
	convert_to_long_ex(auth);
	convert_to_long_ex(active);

	if (!ispageowner((*id)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	if ((*style)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "style", "id=$d", (*style)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	
	if (!mgd_exists_id(mgd_handle(), "person", "id=$d", (*author)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	php_midgard_update(return_value, "page",
			   "name=$q,style=$d,title=$q,changed=Curdate(),"
			   "content=$q,author=$d,info=$d", (*id)->value.lval,
			   (*name)->value.str.val, (*style)->value.lval,
			   (*title)->value.str.val, (*content)->value.str.val,
			   (*author)->value.lval,
			   ((*auth)->value.lval == 1) | ((*active)->value.lval == 1) << 1);
	PHP_UPDATE_REPLIGARD("page", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_page, (type param))
{
    IDINIT;
	CHECK_MGD;
    if(mgd_has_dependants(mgd_handle(),id,"page")
	    || mgd_exists_id(mgd_handle(), "page", "up=$d", id)
	    || mgd_exists_id(mgd_handle(), "host", "root=$d", id)) 
	RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

    if (!ispageowner(id))
	RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	/* check for page elements */
    if (mgd_exists_id(mgd_handle(), "pageelement", "page=$d", id)) RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);
#if HAVE_MIDGARD_PAGELINKS
	/* check for page links */
    if (mgd_exists_id(mgd_handle(), "pagelink", "$d IN (up,target)", id))
    RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);
#endif

    php_midgard_delete(return_value, "page", id);
    PHP_DELETE_REPLIGARD("page", id);
}

MGD_FUNCTION(ret_type, page_has_children, (type param))
{
    IDINIT;
	CHECK_MGD;
   RETVAL_FALSE;
    if (mgd_exists_id(mgd_handle(), "page", "up=$d", id)) { RETVAL_TRUE; }
}
MGD_FUNCTION(ret_type, delete_page_tree, (type param))
{
    IDINIT;
	CHECK_MGD;
   RETVAL_FALSE;
    if (!ispageowner(mgd_idfield(mgd_handle(), "up", "page", id)))
	RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
    if(mgd_exists_id(mgd_handle(), "host", "root=$d", id)) 
	RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);
    if(mgd_delete_page(mgd_handle(),  id))
      RETVAL_TRUE;
}

MGD_MOVE_FUNCTION(page,page,page,up)

MGD_WALK_FUNCTION(page)

MidgardProperty MidgardPageProperties [] = {
	{ IS_LONG,		"up"		},
	{ IS_STRING,	"name"		},
	{ IS_STRING,	"title"		},
	{ IS_STRING,	"content"	},
	{ IS_LONG,		"style"		},
	{ IS_LONG,		"author"	},
	{ IS_LONG,		"auth"		},
	{ IS_LONG,		"active"	},
	{ 0,			NULL		}
};
MIDGARD_CLASS(MidgardPage, page)
