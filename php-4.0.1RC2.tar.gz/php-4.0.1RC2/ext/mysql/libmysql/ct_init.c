/*  Generate definitions of ctype arrays
*/

#include <global.h>
#define CTYPE_LIBRARY		/* initialize ctype arrays */
#include "m_ctype.h"
