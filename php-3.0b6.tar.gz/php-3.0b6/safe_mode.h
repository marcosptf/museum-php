#ifndef _SAFE_MODE_H_
#define _SAFE_MODE_H_

extern int _php3_checkuid(const char *filename, int mode);
extern PHPAPI char *_php3_get_current_user(void);

#endif
