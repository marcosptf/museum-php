#include <signal.h>
#define SIGALRM 13
#define	SIGVTALRM 26			/* virtual time alarm */
#define	SIGPROF	27				/* profiling time alarm */
