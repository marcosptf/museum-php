CREATE TABLE users (
	id varchar(16) NOT NULL,
	password varchar(13),
	PRIMARY KEY (id)
);
