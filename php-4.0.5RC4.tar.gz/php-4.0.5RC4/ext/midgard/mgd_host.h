/* $Id: mgd_host.h,v 1.4 2001/02/28 01:00:31 davidg Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef MGD_HOST_H
#define MGD_HOST_H

extern MGD_FUNCTION(ret_type, is_host_owner, (type param));
extern MGD_FUNCTION(ret_type, list_hosts, (type param));
extern MGD_FUNCTION(ret_type, get_host, (type param));
extern MGD_FUNCTION(ret_type, get_host_by_name, (type param));
extern MGD_FUNCTION(ret_type, create_host, (type param));
extern MGD_FUNCTION(ret_type, update_host, (type param));
extern MGD_FUNCTION(ret_type, delete_host, (type param));

#endif
