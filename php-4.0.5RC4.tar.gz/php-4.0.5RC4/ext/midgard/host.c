/* $Id: host.c,v 1.7 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, is_host_owner, (type param))
{
    IDINIT;
    CHECK_MGD;
    RETVAL_LONG(ishostowner(id));
}

MGD_FUNCTION(ret_type, list_hosts, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 0:
    	php_midgard_select(&MidgardHost, return_value,
		   "id,name,port,online,root,style,owner,info&1 AS auth,prefix," HOSTNAME_FIELD SITEGROUP_SELECT,
		   "host", NULL, "hostname, online DESC");
		return;
	case 1:
		if (zend_get_parameters_ex(1, &id) == SUCCESS) {
			convert_to_long_ex(id);
    		php_midgard_select(&MidgardHost, return_value,
			   "id,name,port,online,root,style,owner,info&1 AS auth,prefix," HOSTNAME_FIELD SITEGROUP_SELECT,
			   "host", "root=$d", "hostname, online DESC", (*id)->value.lval);
			break;
		} /* else fall through */
	default:
		WRONG_PARAM_COUNT;
	}
}

MGD_FUNCTION(ret_type, get_host, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 0:
	php_midgard_bless(return_value, &MidgardHost);
	mgd_object_init(return_value, "name", "port", "online", "root", "style", "auth", "owner", NULL);
		return;
	case 1:
		if (zend_get_parameters_ex(1, &id) == SUCCESS) {
			convert_to_long_ex(id);
			break;
		} /* else fall through */
	default:
		WRONG_PARAM_COUNT;
	}

   php_midgard_get_object(return_value, MIDGARD_OBJECT_HOST, (*id)->value.lval);
}

MGD_FUNCTION(ret_type, get_host_by_name, (type param))
{
    zval **name, **prefix;
	CHECK_MGD;
    if (ZEND_NUM_ARGS() != 2
	|| zend_get_parameters_ex(2, &name, &prefix) != SUCCESS) {
	   WRONG_PARAM_COUNT;
   }

    convert_to_string_ex(name);
    convert_to_string_ex(prefix);

    php_midgard_get_by_name2(&MidgardHost, return_value,
			"id,name,port,online,root,style,info&1 AS auth,owner,prefix," HOSTNAME_FIELD,
			"host", "name", (*name)->value.str.val,
			"prefix", (*prefix)->value.str.val);
}

MGD_FUNCTION(ret_type, create_host, (type param))
{
	zval **name, **port, **online, **root, **style, **auth, **owner, **prefix, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "port", port)
		    || !MGD_PROPFIND(self, "online", online)
		    || !MGD_PROPFIND(self, "root", root)
		    || !MGD_PROPFIND(self, "style", style)
		    || !MGD_PROPFIND(self, "auth", auth)
		    || !MGD_PROPFIND(self, "owner", owner)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
		if (!MGD_PROPFIND(self, "prefix", prefix))
			prefix = NULL;
	}
	else {
		switch (ZEND_NUM_ARGS()) {
			case 7:
				if (zend_get_parameters_ex
				    (7, &name, &port, &online, &root,
				     &style, &auth, &owner) != SUCCESS) {
					WRONG_PARAM_COUNT;
            }

				prefix = NULL;
				break;
			case 8:
				if (zend_get_parameters_ex
				    (8, &name, &port, &online, &root,
				     &style, &auth, &owner, &prefix) != SUCCESS) {
					WRONG_PARAM_COUNT;
            }

				break;
			default:
				WRONG_PARAM_COUNT;
		}
	}
	if (prefix)
	convert_to_string_ex(prefix);
	convert_to_string_ex(name);
	convert_to_long_ex(port);
	convert_to_long_ex(online);
	convert_to_long_ex(root);
	convert_to_long_ex(style);
	convert_to_long_ex(auth);
	convert_to_long_ex(owner);

#if HAVE_MIDGARD_SITEGROUPS
	if (!mgd_isroot(mgd_handle()))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
#else
	if (!mgd_isadmin(mgd_handle()))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
#endif

	if ((*root)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "page", "id=$d", (*root)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if ((*style)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "style", "id=$d", (*style)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if ((*owner)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "grp", "id=$d", (*owner)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	php_midgard_create(return_value, "host",
			   "name,port,online,root,style,info,owner,prefix",
			   "$q,$d,$d,$d,$d,$d,$d,$q", (*name)->value.str.val,
			   (*port)->value.lval, (*online)->value.lval == 1,
			   (*root)->value.lval, (*style)->value.lval,
			   (*auth)->value.lval == 1, (*owner)->value.lval,
			   prefix ? (*prefix)->value.str.val : "");

	PHP_CREATE_REPLIGARD("host", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_host, (type param))
{
	zval **id, **name, **port, **online, **root, **style, **auth, **owner, **prefix, *self;

	midgard_pool *pool = NULL;
	char *prefix_sql = "";
	char *name_port_sql = "";

	RETVAL_FALSE;
	CHECK_MGD;

	if (!(pool = mgd_alloc_pool()))
		RETURN_FALSE_BECAUSE(MGD_ERR_NO_MEM);

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "id", id)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "port", port)
		    || !MGD_PROPFIND(self, "online", online)
		    || !MGD_PROPFIND(self, "root", root)
		    || !MGD_PROPFIND(self, "style", style)
		    || !MGD_PROPFIND(self, "auth", auth)
		    || !MGD_PROPFIND(self, "owner", owner)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}

		if (
#if HAVE_MIDGARD_SITEGROUPS
			   !mgd_isroot(mgd_handle()) ||
#endif
			   !MGD_PROPFIND(self, "prefix", prefix))
			prefix = NULL;
	}
	else {
		switch (ZEND_NUM_ARGS()) {
			case 8:
				if (zend_get_parameters_ex
				    (8, &id, &name, &port, &online, &root,
				     &style, &auth, &owner) != SUCCESS) {
					WRONG_PARAM_COUNT;
            }

				prefix = NULL;
				break;
			case 9:
				if (zend_get_parameters_ex
				    (9, &id, &name, &port, &online, &root,
				     &style, &auth, &owner, &prefix) != SUCCESS) {
					WRONG_PARAM_COUNT;
            }

#if HAVE_MIDGARD_SITEGROUPS
				if (mgd_isroot(mgd_handle())) {
					convert_to_string_ex(prefix);
				} else
					prefix = NULL;
#endif
				break;
			default:
				WRONG_PARAM_COUNT;
		}
	}

	if (prefix) convert_to_string_ex(prefix);
	convert_to_long_ex(id);
	convert_to_string_ex(name);
	convert_to_long_ex(port);
	convert_to_long_ex(online);
	convert_to_long_ex(root);
	convert_to_long_ex(style);
	convert_to_long_ex(auth);
	convert_to_long_ex(owner);

	if (!ishostowner((*id)->value.lval)) {
		mgd_free_pool(pool);
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	}

	if (prefix != NULL)
		prefix_sql =
		   mgd_format(mgd_handle(), pool, ",prefix=$q",
			      (*prefix)->value.str.val);

#if HAVE_MIDGARD_SITEGROUPS
	if (mgd_isroot(mgd_handle()))
		name_port_sql =
		   mgd_format(mgd_handle(), pool, ",name=$q,port=$d",
			      (*name)->value.str.val, (*port)->value.lval);
#else
	name_port_sql =
	   mgd_format(mgd_handle(), pool, ",name=$q,port=$d",
		      (*name)->value.str.val, (*port)->value.lval);
#endif

	if ((*root)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "page", "id=$d", (*root)->value.lval)) {
		mgd_free_pool(pool);
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }

	if ((*style)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "style", "id=$d", (*style)->value.lval)) {
		mgd_free_pool(pool);
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }

	if ((*owner)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "grp", "id=$d", (*owner)->value.lval)) {
		mgd_free_pool(pool);
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }

	php_midgard_update(return_value, "host",
			   "online=$d,root=$d,"
			   "style=$d,info=$d,owner=$d $s $s",
			   (*id)->value.lval,
			   (*online)->value.lval == 1,
			   (*root)->value.lval, (*style)->value.lval,
			   (*auth)->value.lval == 1, (*owner)->value.lval,
			   prefix_sql, name_port_sql);
	PHP_UPDATE_REPLIGARD("host", (*id)->value.lval);
	mgd_free_pool(pool);
}

MGD_FUNCTION(ret_type, delete_host, (type param))
{
    IDINIT;
	CHECK_MGD;
    if(mgd_has_dependants(mgd_handle(),id,"host"))
	RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

#if HAVE_MIDGARD_SITEGROUPS
	if (!mgd_isroot(mgd_handle())) RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
#else
    if (!ishostowner(id)) RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
#endif
    php_midgard_delete(return_value, "host", id);
    PHP_DELETE_REPLIGARD("host", id);
}

MidgardProperty MidgardHostProperties [] = {
	{ IS_STRING,	"name"		},
	{ IS_LONG,		"port"		},
	{ IS_STRING,	"prefix"	},
	{ IS_LONG,		"online"	},
	{ IS_LONG,		"root"		},
	{ IS_LONG,		"style"		},
	{ IS_LONG,		"owner"		},
	{ IS_LONG,		"auth"		},
	{ 0,			NULL		}
};

MIDGARD_CLASS(MidgardHost, host)
