/* $Id: parameter.c,v 1.4 2001/02/28 01:00:32 davidg Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "php.h"
#include "php_ini.h"
#include "php_midgard.h"
#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, oop_parameter, (type param))
{
	zval *self;
	zval **zv_domain, **zv_name, **zv_value;
	zval **zv_table, **zv_id;
	int id = 0;
	midgard_res *res;
	int exists;

	CHECK_MGD;

	if ((self = getThis()) == NULL) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
	}

   if (zend_hash_find(self->value.obj.properties, "__table__", 10,
	     (void **) &zv_table) != SUCCESS) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

   if (zend_hash_find(self->value.obj.properties, "id", 3,
	     (void **) &zv_id) !=
	    SUCCESS) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

	convert_to_string_ex(zv_table);
	convert_to_long_ex(zv_id);

	switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &zv_domain, &zv_name) ==
			    FAILURE) {
				WRONG_PARAM_COUNT;
			}
			convert_to_string_ex(zv_domain);
			convert_to_string_ex(zv_name);
			zv_value = NULL;
			break;

		case 3:
			if (zend_get_parameters_ex
			    (3, &zv_domain, &zv_name, &zv_value) == FAILURE) {
				WRONG_PARAM_COUNT;
			}
			convert_to_string_ex(zv_domain);
			convert_to_string_ex(zv_name);
			convert_to_string_ex(zv_value);
			break;

		default:
			WRONG_PARAM_COUNT;
	}

	res = mgd_ungrouped_select(mgd_handle(), "id,value,sitegroup",
				   "record_extension",
				   "tablename=$q AND oid=$d AND domain=$q AND name=$q",
				   NULL,
				   (*zv_table)->value.str.val,
				   (*zv_id)->value.lval,
				   (*zv_domain)->value.str.val,
				   (*zv_name)->value.str.val);

	exists = res ? mgd_fetch(res) : 0;
	if (exists)
		id = atoi(mgd_colvalue(res, 0));

	/* delete parameter */
	if (zv_value && (*zv_value)->value.str.len == 0) {

		if (res) { mgd_release(res); }

		if (!isglobalowner(
				mgd_lookup_table_id((*zv_table)->value.str.val),
				(*zv_id)->value.lval)) {
			RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
		}

		if (!exists) {
			RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
		}

		if (mgd_delete(mgd_handle(), "record_extension", id)) {
			PHP_DELETE_REPLIGARD("record_extension", id);
			RETURN_TRUE;
		}
		else {
			RETURN_FALSE_BECAUSE(MGD_ERR_INTERNAL);
		}
	}

	/* return parameter */
	if (!zv_value) {

		if (!res) {
			RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
		}
		if (!exists) {
			mgd_release(res);
			RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
		}

		RETVAL_STRING((char *) mgd_colvalue(res, 1), 1);
	}
	else {
		/* update parameter */

		if (exists) {
			if (!isglobalowner(
					mgd_lookup_table_id((*zv_table)->value.str.val),
					(*zv_id)->value.lval)) {
				if (res) mgd_release(res);
				RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
			}

			php_midgard_update(return_value, "record_extension",
					   "value=$q", id,
					   (*zv_value)->value.str.val);
			PHP_UPDATE_REPLIGARD("record_extension", id);
		}
		else {
			php_midgard_create(return_value, "record_extension",
					   "tablename,oid,domain,name,value",
					   "$q,$d,$q,$q,$q",
					   (*zv_table)->value.str.val,
					   (*zv_id)->value.lval,
					   (*zv_domain)->value.str.val,
					   (*zv_name)->value.str.val,
					   (*zv_value)->value.str.val);
			PHP_CREATE_REPLIGARD("record_extension",
					     return_value->value.lval);
		}
	}

	if (res)
		mgd_release(res);
}

MGD_FUNCTION(ret_type, oop_parameter_list, (type param))
{
	zval *self;
	zval **zv_domain;
	zval **zv_table, **zv_id;

	CHECK_MGD;

	if ((self = getThis()) == NULL) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
	}

   if (zend_hash_find(self->value.obj.properties, "id", 3,
	     (void **) &zv_id) !=
	    SUCCESS) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

   if (zend_hash_find(self->value.obj.properties, "__table__", 10,
	     (void **) &zv_table) != SUCCESS) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

	convert_to_string_ex(zv_table);
	convert_to_long_ex(zv_id);

	switch (ZEND_NUM_ARGS()) {
		case 1:
			if (zend_get_parameters_ex(1, &zv_domain) == FAILURE) {
				WRONG_PARAM_COUNT;
			}
			convert_to_string_ex(zv_domain);
			break;

		case 0:
			zv_domain = NULL;
			break;

		default:
			WRONG_PARAM_COUNT;
	}

	if (zv_domain)
		php_midgard_select(&MidgardParameter, return_value,
               "domain,name,value",
				   "record_extension",
				   "tablename=$q AND oid=$d AND domain=$q",
				   "name",
				   (*zv_table)->value.str.val,
				   (*zv_id)->value.lval,
				   (*zv_domain)->value.str.val);
	else
		php_midgard_select(&MidgardParameter, return_value,
               "DISTINCT domain",
				   "record_extension",
				   "tablename=$q AND oid=$d", "domain",
				   (*zv_table)->value.str.val,
				   (*zv_id)->value.lval);
}

MGD_FUNCTION(ret_type, oop_parameter_search, (type param))
{
	zval *self, **table;
	zval **where, **all;
	char *cond = NULL;
	midgard_pool *pool;

	RETVAL_FALSE;

	CHECK_MGD;

	if ((self = getThis()) == NULL) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

   if (zend_hash_find(self->value.obj.properties, "__table__", 10,
      (void **) &table)
	    != SUCCESS) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

	convert_to_string_ex(table);

	switch (ZEND_NUM_ARGS()) {
		case 1:
			if (zend_get_parameters_ex(1, &where) != SUCCESS) {
				WRONG_PARAM_COUNT;
			}
			convert_to_string_ex(where);
			all = NULL;
			break;
		case 2:
			if (zend_get_parameters_ex(2, &where, &all) != SUCCESS) {
				WRONG_PARAM_COUNT;
			}
			convert_to_string_ex(where);
			convert_to_boolean_ex(all);
			break;
		default:
			WRONG_PARAM_COUNT;
	}

	if (*((*table)->value.str.val) == '\0') {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	}

	if (!(pool = mgd_alloc_pool())) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NO_MEM);
	}

	cond = mgd_format(mgd_handle(), pool, "tablename = $q AND ($s)",
			  (*table)->value.str.val,
			  ((*((*where)->value.str.val) == '\0') ? (*where)->
			   value.str.val : "1=1")
	   );

	if (all != NULL && (*all)->value.lval) {
		php_midgard_select(&MidgardParameter, return_value,
				   "oid AS id,id AS pid,domain,name,value",
				   "record_extension", cond, NULL);
	}
	else {
		php_midgard_select(&MidgardParameter, return_value,
				   "DISTINCT oid AS id",
				   "record_extension", cond, NULL);
	}

	mgd_free_pool(pool);
}

MidgardProperty MidgardParameterProperties [] = {
	{ IS_LONG,		"oid"		},
	{ IS_STRING,	"tablename"	},
	{ IS_STRING,	"domain"	},
	{ IS_STRING,	"name"		},
	{ IS_STRING,	"value"		},
	{ 0,			NULL		}
};

MIDGARD_HANDLERS_DECL(parameter)
static zend_function_entry MidgardParameterMethods[] = {
//      MidgardParameter class constructor
//      PHP_FALIAS(midgardparameter,   mgd_ctor_parameter,  NULL)
   PHP_FALIAS(fetch,    mgd_oop_list_fetch,        NULL)
   {  NULL,             NULL,                      NULL}
};
MidgardClass MidgardParameter = {
   "MidgardParameter",
   "record_extension",
   MidgardParameterMethods,
   {},
   mgd_parameter_call_function_handler,
   mgd_parameter_get_property_handler,
   mgd_parameter_set_property_handler,
   MidgardParameterProperties,
   NULL
};
MIDGARD_HANDLERS(MidgardParameter, parameter)

