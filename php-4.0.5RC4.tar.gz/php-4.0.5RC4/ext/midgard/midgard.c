/* $Id: midgard.c,v 1.22.2.1 2001/03/19 07:52:03 ab Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "php.h"
#include "ext/standard/info.h"
#include "php_midgard.h"

/* You should tweak config.m4 so this symbol (or some else suitable)
   gets defined.
*/
#if HAVE_MIDGARD

#include <http_config.h>
#include "mgd_errno.h"
#include "mgd_internal.h"
#include "mgd_oop.h"
#include "mgd_mail.h"
#include "mgd_article.h"
#include "mgd_topic.h"
#include "mgd_attachment.h"
#include "mgd_element.h"
#include "mgd_group.h"
#include "mgd_file.h"
#include "mgd_member.h"
#include "mgd_host.h"
#include "mgd_image.h"
#include "mgd_calendar.h"
#include "mgd_event.h"
#include "mgd_eventmember.h"
#include "mgd_page.h"
#include "mgd_pageelement.h"
#include "mgd_pagelink.h"
#include "mgd_person.h"
#include "mgd_preferences.h"
#include "mgd_sitegroup.h"
#include "mgd_snippet.h"
#include "mgd_snippetdir.h"
#include "mgd_style.h"
#include "mgd_preparser.h"


ZEND_DECLARE_MODULE_GLOBALS(midgard)

/* True global resources - no need for thread safety here */
/* DG: supress warning
static int le_midgard;
*/

MGD_FUNCTION(ret_type, errno, (type param));
MGD_FUNCTION(ret_type, errstr, (type param));
MGD_FUNCTION(ret_type, version, (type param));
MGD_FUNCTION(ret_type, get_midgard, (type param));
MGD_FUNCTION(ret_type, auth_midgard, (type param));
#if YOU_WANT_TO_TEST
MGD_FUNCTION(ret_type, walk_tree, (type param));
#endif

/* Every user visible function must have an entry in midgard_functions[].
*/
function_entry midgard_functions[] = {
PHP_FE(confirm_midgard_compiled,	NULL)		/* For testing, remove later. */
MGD_FE(is_article_owner, NULL)
MGD_FE(is_article_in_topic_tree, NULL)
MGD_FE(list_topic_articles, NULL)
MGD_FE(list_reply_articles, NULL)
MGD_FE(list_topic_articles_all, NULL)
MGD_FE(list_topic_articles_all_fast, NULL)
MGD_FE(list_topic_articles_all_of_person, NULL)
MGD_FE(get_article, NULL)
MGD_FE(get_article_by_name, NULL)
MGD_FE(get_reply_by_name, NULL)
MGD_FE(create_article, NULL)
MGD_FE(update_article_score, NULL)
MGD_FE(update_article_created, NULL)
MGD_FE(update_article_replyto, NULL)
MGD_FE(update_article_type, NULL)
MGD_FE(toggle_article_lock, NULL)
MGD_FE(approve_article, NULL)
MGD_FE(update_article, NULL)
MGD_FE(delete_article, NULL)
MGD_FE(copy_article, NULL)
MGD_FE(move_article, NULL)
MGD_FE(move_reply, NULL)
MGD_FE(delete_article_tree, NULL)
MGD_FE(open_attachment, NULL)
MGD_FE(get_attachment, NULL)
MGD_FE(serve_attachment, NULL)
MGD_FE(stat_attachment, NULL)
MGD_FE(delete_attachment, NULL)
MGD_FE(update_attachment, NULL)
//MGD_FE(errno, NULL)
//MGD_FE(errstr, NULL)
//MGD_FE(version, NULL)
MGD_FE(is_topic_owner, NULL)
MGD_FE(list_topics, NULL)
MGD_FE(is_in_topic_tree, NULL)
MGD_FE(get_topic, NULL)
MGD_FE(get_topic_by_name, NULL)
MGD_FE(create_topic, NULL)
MGD_FE(update_topic, NULL)
MGD_FE(update_topic_score, NULL)
MGD_FE(delete_topic, NULL)
MGD_FE(copy_topic, NULL)
MGD_FE(move_topic, NULL)
MGD_FE(delete_topic_tree, NULL)
MGD_FE(list_elements, NULL)
MGD_FE(get_element, NULL)
MGD_FE(get_element_by_name, NULL)
MGD_FE(create_element, NULL)
MGD_FE(update_element, NULL)
MGD_FE(delete_element, NULL)
MGD_FE(copy_element, NULL)
MGD_FE(move_element, NULL)
MGD_FE(errno, NULL)
MGD_FE(errstr, NULL)
MGD_FE(version, NULL)
MGD_FE(get_midgard, NULL)
MGD_FE(auth_midgard, NULL)
MGD_FE(create_mail, NULL)
MGD_FE(is_group_owner, NULL)
MGD_FE(list_groups, NULL)
MGD_FE(get_group, NULL)
MGD_FE(get_group_by_name, NULL)
MGD_FE(create_group, NULL)
MGD_FE(update_group, NULL)
MGD_FE(delete_group, NULL)
MGD_FE(list_files, NULL)
MGD_FE(get_file, NULL)
MGD_FE(create_file, NULL)
MGD_FE(update_file, NULL)
MGD_FE(delete_file, NULL)
MGD_FE(list_members, NULL)
MGD_FE(list_memberships, NULL)
MGD_FE(get_member, NULL)
MGD_FE(create_member, NULL)
MGD_FE(update_member, NULL)
MGD_FE(delete_member, NULL)
MGD_FE(is_host_owner, NULL)
MGD_FE(list_hosts, NULL)
MGD_FE(get_host, NULL)
MGD_FE(get_host_by_name, NULL)
MGD_FE(create_host, NULL)
MGD_FE(update_host, NULL)
MGD_FE(delete_host, NULL)
MGD_FE(list_images, NULL)
#if 0
MGD_FE(html_image, NULL)
#endif
MGD_FE(get_image, NULL)
MGD_FE(create_image, NULL)
MGD_FE(update_image, NULL)
MGD_FE(delete_image, NULL)
MGD_FE(list_topic_calendar_all, NULL)
MGD_FE(list_topic_calendar_all_fast, NULL)
MGD_FE(is_event_owner, NULL)
MGD_FE(create_event, NULL)
MGD_FE(update_event, NULL)
MGD_FE(delete_event, NULL)
MGD_FE(delete_event_tree, NULL)
MGD_FE(get_event, NULL)
MGD_FE(list_events, NULL)
MGD_FE(list_events_between, NULL)
MGD_FE(list_events_all, NULL)
MGD_FE(list_events_all_between, NULL)
MGD_FE(count_events_in_period, NULL)
MGD_FE(count_events_in_month, NULL)
MGD_FE(copy_event, NULL)
MGD_FE(move_event, NULL)
MGD_FE(create_event_member, NULL)
MGD_FE(update_event_member, NULL)
MGD_FE(delete_event_member, NULL)
MGD_FE(get_event_member, NULL)
MGD_FE(list_event_members, NULL)
MGD_FE(count_event_members, NULL)
MGD_FE(is_page_owner, NULL)
MGD_FE(copy_page, NULL)
MGD_FE(move_page, NULL)
MGD_FE(list_pages, NULL)
MGD_FE(is_in_page_tree, NULL)
MGD_FE(get_page, NULL)
MGD_FE(get_page_by_name, NULL)
MGD_FE(create_page, NULL)
MGD_FE(update_page, NULL)
MGD_FE(delete_page, NULL)
MGD_FE(page_has_children, NULL)
MGD_FE(delete_page_tree, NULL)
MGD_FE(list_page_elements, NULL)
MGD_FE(get_page_element, NULL)
MGD_FE(get_page_element_by_name, NULL)
MGD_FE(create_page_element, NULL)
MGD_FE(update_page_element, NULL)
MGD_FE(delete_page_element, NULL)
MGD_FE(copy_page_element, NULL)
MGD_FE(move_page_element, NULL)
MGD_FE(has_pagelinks, NULL)
#if HAVE_MIDGARD_PAGELINKS
MGD_FE(is_pagelink_owner, NULL)
MGD_FE(list_pagelinks, NULL)
MGD_FE(list_pagelinks_targeted_at, NULL)
MGD_FE(get_pagelink, NULL)
MGD_FE(get_pagelink_by_name, NULL)
MGD_FE(create_pagelink, NULL)
MGD_FE(update_pagelink, NULL)
MGD_FE(delete_pagelink, NULL)
#endif
MGD_FE(is_person_owner, NULL)
MGD_FE(is_member, NULL)
MGD_FE(list_persons, NULL)
MGD_FE(list_persons_in_department, NULL)
MGD_FE(list_topic_persons, NULL)
MGD_FE(list_persons_in_department_all, NULL)
MGD_FE(list_topic_persons_all, NULL)
MGD_FE(list_persons_in_office, NULL)
MGD_FE(get_person, NULL)
MGD_FE(create_person, NULL)
MGD_FE(update_person, NULL)
MGD_FE(update_password, NULL)
MGD_FE(update_password_plain, NULL)
MGD_FE(update_public, NULL)
MGD_FE(delete_person, NULL)
MGD_FE(list_preferences, NULL)
MGD_FE(get_preference, NULL)
MGD_FE(create_preference, NULL)
MGD_FE(update_preference, NULL)
MGD_FE(delete_preference, NULL)
MGD_FE(has_sitegroups, NULL)
#if HAVE_MIDGARD_SITEGROUPS
MGD_FE(list_sitegroups, NULL)
MGD_FE(create_sitegroup, NULL)
MGD_FE(get_sitegroup, NULL)
MGD_FE(update_sitegroup, NULL)
MGD_FE(delete_sitegroup, NULL)
#endif
MGD_FE(snippet_exists, NULL)
MGD_FE(list_snippets, NULL)
MGD_FE(get_snippet, NULL)
MGD_FE(get_snippet_by_name, NULL)
MGD_FE(create_snippet, NULL)
MGD_FE(update_snippet, NULL)
MGD_FE(delete_snippet, NULL)
MGD_FE(copy_snippet, NULL)
MGD_FE(move_snippet, NULL)
MGD_FE(is_snippetdir_owner, NULL)
MGD_FE(list_snippetdirs, NULL)
MGD_FE(get_snippetdir, NULL)
MGD_FE(get_snippetdir_by_path, NULL)
MGD_FE(create_snippetdir, NULL)
MGD_FE(update_snippetdir, NULL)
MGD_FE(delete_snippetdir, NULL)
MGD_FE(delete_snippetdir_tree, NULL)
MGD_FE(copy_snippetdir, NULL)
MGD_FE(move_snippetdir, NULL)
MGD_FE(walk_style_tree, NULL)
MGD_FE(walk_topic_tree, NULL)
MGD_FE(walk_article_tree, NULL)
MGD_FE(walk_page_tree, NULL)
MGD_FE(walk_snippetdir_tree, NULL)
MGD_FE(walk_event_tree, NULL)
MGD_FE(walk_group_tree, NULL)
MGD_FE(is_style_owner, NULL)
MGD_FE(list_styles, NULL)
MGD_FE(get_style, NULL)
MGD_FE(get_style_by_name, NULL)
MGD_FE(create_style, NULL)
MGD_FE(update_style, NULL)
MGD_FE(delete_style, NULL)
MGD_FE(copy_style, NULL)
MGD_FE(move_style, NULL)
MGD_FE(delete_style_tree, NULL)
MGD_FE(get_object_by_guid, NULL)
/* preparser functions */
MGD_FE(template, NULL)
MGD_FE(variable, NULL)
MGD_FE(snippet, NULL)
MGD_FE(eval, NULL)
MGD_FE(register_filter, NULL)
#if YOU_WANT_TO_TEST
MGD_FE(walk_tree, NULL)
#endif
	{NULL, NULL, NULL}	/* Must be the last line in midgard_functions[] */
};

zend_module_entry midgard_module_entry = {
	"midgard",
	midgard_functions,
	PHP_MINIT(midgard),
	PHP_MSHUTDOWN(midgard),
	PHP_RINIT(midgard),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(midgard),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(midgard),
	STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_MIDGARD
ZEND_GET_MODULE(midgard)
#endif

/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
PHP_INI_END()
*/

static void php_midgard_init_globals(zend_midgard_globals *midgard_globals)
{
	midgard_globals->rcfg = NULL;
	midgard_globals->dcfg = NULL;
	midgard_globals->mgd = NULL;
	midgard_globals->mgd_errno = MGD_ERR_OK;
	midgard_globals->udf = NULL;
}

PHP_MINIT_FUNCTION(midgard)
{
	MidgardClassPtr *midgard_class;

	ZEND_INIT_MODULE_GLOBALS(midgard, php_midgard_init_globals, NULL);
/* Remove comments if you have entries in php.ini
	REGISTER_INI_ENTRIES();
*/

	for (midgard_class = MidgardClasses; midgard_class &&
							*midgard_class; midgard_class++) {
		if(*midgard_class && (*midgard_class)->name) {
			MGD_INIT_OVERLOADED_CLASS_ENTRY(
				(*midgard_class)->class_entry,
				(*midgard_class)->name,
				(*midgard_class)->methods,
				NULL,
				//(*midgard_class)->function_call,
				NULL,
				//(*midgard_class)->get_property,
				(*midgard_class)->set_property
			);
		}
      (*midgard_class)->entry_ptr =
         zend_register_internal_class(&((*midgard_class)->class_entry));
      assert((*midgard_class)->entry_ptr);
   }
	return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(midgard)
{
/* Remove comments if you have entries in php.ini
	UNREGISTER_INI_ENTRIES();
*/
	return SUCCESS;
}

/* Remove if there's nothing to do at request start */
PHP_RINIT_FUNCTION(midgard)
{
	request_rec *r;
	module *midgard_module;

	SLS_FETCH();
	MGDLS_FETCH();
	
	/* set apache log facilities available to the library */
	mgd_set_log_debug_func(mgd_log_debug);

	midgard_module = ap_find_linked_module("mod_midgard.c");
	if (!midgard_module) {
		MGDG(rcfg) = NULL;
		MGDG(dcfg) = NULL;
		php_error(E_ERROR, "Cannot get midgard module descriptor");
		return SUCCESS;
	}

	/* Failure on Apache 1.3.18-dev (Marius) ??? */
	r = ((request_rec *) SG(server_context));

	MGDG(rcfg) = (midgard_request_config *)
			ap_get_module_config(r->request_config, midgard_module);
	if(MGDG(rcfg) == NULL) {
      /* Midgard is probably not enabled for this host, only log debug info */
		MGD_LOG_START("Cannot get midgard module config")
		MGD_LOG_END()

		MGDG(rcfg) = NULL;
		MGDG(dcfg) = NULL;
		return SUCCESS;
	}

	MGDG(dcfg) = (midgard_directory_config *)
	   ap_get_module_config(r->per_dir_config, midgard_module);
	if(MGDG(dcfg) == NULL) {
		MGD_LOG_START("Cannot get midgard module directory config")
		MGD_LOG_END()

      /* this is an error, since if we can get the module config we should
         also be able to get this
      */
		php_error(E_NOTICE, "Cannot get midgard module directory config");
		MGDG(rcfg) = NULL;
		MGDG(dcfg) = NULL;
		return SUCCESS;
	}

	MGDG(mgd) = MGDG(rcfg)->mgd;
	ALLOC_INIT_ZVAL(MGDG(udf));
	if(MGDG(udf)) array_init(MGDG(udf));

	return SUCCESS;
}

/* Remove if there's nothing to do at request end */
PHP_RSHUTDOWN_FUNCTION(midgard)
{
	zval *udf = mgd_getudf();
	if(udf) zval_dtor(udf);

	if (mgd_rcfg() == NULL && mgd_handle() != NULL) {
		mgd_close(mgd_handle());
		/* EEH: not safe! mgd_done(); */
	}

	return SUCCESS;
}

PHP_MINFO_FUNCTION(midgard)
{
	int i;
	php_info_print_table_start();
	php_info_print_table_header(2, "Midgard Support", "enabled");
	php_info_print_table_row(2, "Midgard version", mgd_version());
	i = 0;
	/* TODO: pretify output by arranging functions according object classes */
	while (midgard_module_entry.functions[i].fname) {
		php_info_print_table_row(2, "", midgard_module_entry.functions[i].fname);
		i++;
	}
	php_info_print_table_end();
	php_info_print_box_start(0);
	PUTS("<H3><a href=\"http://www.midgard-project.org/\">");
	PUTS("The Midgard Project Home Page</a></H3>\n");

	php_printf("This program makes use of the Midgard Content Management engine:<BR>");
	php_printf("&copy; 1998-2001 The Midgard Project Ry - 2000-2001 Aurora Linux</BR>\n");
	php_info_print_box_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}

/* Remove the following function when you have succesfully modified config.m4
   so that your module can be compiled into PHP, it exists only for testing
   purposes. */

/* Every user-visible function in PHP should document itself in the source */
/* {{{ proto string confirm_midgard_compiled(string arg)
   Return a string to confirm that the module is compiled in */
PHP_FUNCTION(confirm_midgard_compiled)
{
	zval **arg;
	int len;
	char string[256];

	if (ZEND_NUM_ARGS() != 1 || zend_get_parameters_ex(1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_string_ex(arg);

	len = sprintf(string, "Congratulations, you have successfully modified ext/midgard/config.m4, module %s is compiled into PHP", Z_STRVAL_PP(arg));
	RETURN_STRINGL(string, len, 1);
}
/* }}} */
/* The previous line is meant for emacs, so it can correctly fold and unfold
   functions in source code. See the corresponding marks just before function
   definition, where the functions purpose is also documented. Please follow
   this convention for the convenience of others editing your code.
*/

MGD_FUNCTION(ret_type, errno, (type param))
{
   if (ZEND_NUM_ARGS() != 0) WRONG_PARAM_COUNT;

    RETURN_LONG(mgd_get_errno());
}

MGD_FUNCTION(ret_type, errstr, (type param))
{
   zval **errcode;
   char *err;

   switch(ZEND_NUM_ARGS()) {
      case 0:
         errcode = NULL;
         break;
      case 1:
         if (zend_get_parameters_ex(1, &errcode)==FAILURE)
            WRONG_PARAM_COUNT;
         break;
      default:
         WRONG_PARAM_COUNT;
   }

   if (errcode) convert_to_long_ex(errcode);

   err = mgd_errstr(errcode ? (*errcode)->value.lval : mgd_get_errno());

   RETURN_STRING(err, 1);
}

MGD_FUNCTION(ret_type, version, (type param))
{
   RETURN_STRING((char*)mgd_version(), 1);
}

/* Fetch static globals. Unfortunately these need to be here since the
   module globals are declared static by the Zend macros
*/
midgard_request_config *mgd_rcfg()
{
   MGDLS_FETCH();
   return MGDG(rcfg);
}

midgard_directory_config *mgd_dcfg()
{
   MGDLS_FETCH();
   return MGDG(dcfg);
}

midgard *mgd_handle()
{
   MGDLS_FETCH();
   return MGDG(mgd);
}

zval *mgd_getudf()
{
   MGDLS_FETCH();
   return MGDG(udf);
}

void mgd_set_errno(int mgd_errno)
{
   MGDLS_FETCH();
   if (MGDG(mgd_errno) == MGD_ERR_OK)
      MGDG(mgd_errno) = mgd_errno;
}

void mgd_reset_errno(void)
{
   MGDLS_FETCH();
   MGDG(mgd_errno) = MGD_ERR_OK;
}

int mgd_get_errno()
{
   MGDLS_FETCH();
   return MGDG(mgd_errno);
}

void mgd_log_debug(int flags, const char *fmt, ...)
{
	midgard_pool *pool;
	char *str;
	va_list args;

	pool = mgd_alloc_pool();
	va_start(args, fmt);
	str = mgd_vformat(mgd_handle(), pool, fmt, args);
	va_end(args);
	MGD_LOG_START("\nDEBUG: %s") MGD_LOG_ARG(str) MGD_LOG_END()
	mgd_free_pool(pool);
}

MGD_FUNCTION(ret_type, get_midgard, (type param))
{
	int i;
	zval *argv, *types;
	char **mm_argv;
	long mm_argc;
	midgard *mgd = mgd_handle();
	midgard_request_config *rcfg = mgd_rcfg();

	if (rcfg == NULL) {
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_CONNECTED);
	}

	object_init(return_value);

	add_property_long(return_value, "host", rcfg->host);
	add_property_long(return_value, "style", rcfg->style);
	add_property_long(return_value, "page", rcfg->resource.id);
	add_property_long(return_value, "cookieauth", rcfg->auth.cookie);
	add_property_long(return_value, "auth", rcfg->auth.required);
	add_property_long(return_value, "author", rcfg->author);

	add_property_long(return_value, "user", mgd_user(mgd));
	add_property_long(return_value, "admin", mgd_isadmin(mgd));

#if HAVE_MIDGARD_SITEGROUPS
	add_property_long(return_value, "root", mgd_isroot(mgd));
	add_property_long(return_value, "sitegroup", mgd_sitegroup(mgd));
#endif

	mm_argv = (char**)rcfg->argv->elts;
	mm_argc = rcfg->argv->nelts;
	add_property_long(return_value, "argc", mm_argc);

	MAKE_STD_ZVAL(argv);
	array_init(argv);
	for (i = 0; i < mm_argc; i++) {
		add_index_string(argv, i, mm_argv[i], 1);
	}

	/* EEH {HACK ALERT}: We add this property with hash_update
	   manually since Zend doesn't offer a add_property_array.
	   DG {END HACK ALERT} TODO: replace by the following line in PHP 4.0.5
	   add_property_zval(return_value, "argv", argv);
	 */
	zend_hash_update(return_value->value.obj.properties, "argv", 5,
			 &argv, sizeof(argv), NULL);

	add_property_string(return_value, "uri", rcfg->req->uri, 1);

	add_property_stringl(return_value, "self",
			     rcfg->req->uri, rcfg->self_len, 1);

	MAKE_STD_ZVAL(types);
	array_init(types);
	for (i = 1; i < MIDGARD_OBJECT_COUNT; i++) {
		add_assoc_long(types, (char *)mgd_table_extname[i], i);
	}

	//add_property_zval(return_value, "types", types);
	zend_hash_update(return_value->value.obj.properties, "types", 6,
			 &types, sizeof(types), NULL);
}

MGD_FUNCTION(ret_type, auth_midgard, (type param))
{
	zval **username, **password, **send_cookie;
	char *cookie1;
	static const char *cookie2;
	char cookie3[256];
	static const char *u, *p;
	int rv;
	int sc;

   request_rec *r;

   SLS_FETCH();

   r = ((request_rec *) SG(server_context));

	CHECK_MGD;

	RETVAL_FALSE;

	switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &username, &password) !=
			    SUCCESS) {
				WRONG_PARAM_COUNT;
			}
			sc = 1;
			break;

		case 3:
			if (zend_get_parameters_ex
			    (3, &username, &password,
			     &send_cookie) != SUCCESS) {
				WRONG_PARAM_COUNT;
			}
			convert_to_boolean_ex(send_cookie);
			sc = (*send_cookie)->value.lval;
			break;

		default:
			WRONG_PARAM_COUNT;
			break;
	}

	convert_to_string_ex(username);
	convert_to_string_ex(password);

	if ((*username)->value.str.len)
		u = ap_pstrdup(mgd_rcfg()->pool, (*username)->value.str.val);
	else
		u = "";
	if ((*password)->value.str.len)
		p = ap_pstrdup(mgd_rcfg()->pool, (*password)->value.str.val);
	else
		p = "";

	rv = mgd_auth(mgd_handle(), u, p);
	if (rv >= 0 && sc) {
		cookie1 = ap_psprintf(r->pool, "%s:%s",
				      (*username)->value.str.val,
				      (*password)->value.str.val);
		cookie2 = ap_uuencode(r->pool, cookie1);
		sprintf(cookie3,
			"MidgardLogin=%s;"
			" Expires=Friday, 1-Jan-%d10 12:00:00 GMT;"
			" Path=/", cookie2, mgd_user(mgd_handle())? 20 : 10);
		ap_table_set(r->headers_out, "Set-Cookie",
			     cookie3);
	}

	switch (rv) {
		case MGD_AUTH_NOT_CONNECTED:
			RETURN_FALSE_BECAUSE(MGD_ERR_NOT_CONNECTED);

		case MGD_AUTH_INVALID_NAME:
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_NAME);

		case MGD_AUTH_SG_NOTFOUND:
			RETURN_FALSE_BECAUSE(MGD_ERR_SG_NOTFOUND);

		case MGD_AUTH_DUPLICATE:
			RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

		case MGD_AUTH_NOTFOUND:
			RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

		case MGD_AUTH_REAUTH:
		case MGD_AUTH_INVALID_PWD:
			RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

		default:
			if (rv >= 0) {
				RETVAL_TRUE;
			}
			else {
				RETURN_FALSE_BECAUSE(MGD_ERR_INTERNAL);
			}
	}
}

int midgard_user_call_func(midgard *mgd, int id, int level, void *xparam)
{
	zval *args[3];
	zval ** xp = (zval **)xparam;
	zval *return_value;
	int retval;

	if(!PZVAL_IS_REF(xp[0])) {
		/* DG: Do we force the user to pass it by reference ? */
		php_error(E_WARNING,"You must pass the fourth parameter by reference.");
		return 0;
	}

	MAKE_STD_ZVAL(return_value);	ZVAL_NULL(return_value);
	MAKE_STD_ZVAL(args[0]);		   ZVAL_LONG(args[0], id);
	MAKE_STD_ZVAL(args[1]);		   ZVAL_LONG(args[1], level);
	args[2] = xp[0];		// DG: is this needed ? ->zval_copy_ctor(args[2]);

	if(call_user_function(CG(function_table), NULL,
				  xp[1], return_value, 3,
				  args) != SUCCESS) {
		php_error(E_WARNING,"Unable to call %s() - function does not exist",
				  (xp[1])->value.str.val);
		zval_dtor(return_value);
		zval_dtor(args[0]); zval_dtor(args[1]);
		return 0;
	}
	if(return_value->type == IS_NULL)
		retval = 1;
	else {
		convert_to_long_ex(&return_value);
		retval = return_value->value.lval;
	}
	zval_dtor(return_value);
	zval_dtor(args[0]); zval_dtor(args[1]);
	return retval;
}

#if YOU_WANT_TO_TEST
MGD_FUNCTION(ret_type, walk_tree, (type param))
{
	zval **id, **level, **xparam, *xp[2], **order;
	zval **midgard_user_call_func_name, **sort = NULL;
	zval **tableid, **upfield;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 8:
      if (zend_get_parameters_ex(8, &tableid, &upfield,
			&midgard_user_call_func_name, &id,
            &level, &xparam, &order, &sort) == FAILURE) {
         WRONG_PARAM_COUNT;
      }
      break;
	case 7:
      if (zend_get_parameters_ex(7, &tableid, &upfield,
			&midgard_user_call_func_name, &id,
            &level, &xparam, &order) == FAILURE) {
         WRONG_PARAM_COUNT;
      } else {
         sort = NULL;
      }
      break;
   case 6:
      if (zend_get_parameters_ex(6, &tableid, &upfield,
			&midgard_user_call_func_name, &id,
            &level, &xparam) == FAILURE) {
         WRONG_PARAM_COUNT;
      } else {
         order = NULL;
         sort = NULL;
      }
      break;
   default:
      WRONG_PARAM_COUNT;
      break;
   }

	convert_to_long_ex(tableid);
	if(!(*tableid)->value.lval) RETURN_FALSE;
	convert_to_string_ex(upfield);
	convert_to_string_ex(midgard_user_call_func_name);
	convert_to_long_ex(level);
	if (order) convert_to_long_ex(order);
	convert_to_long_ex(id);
	if(sort) convert_to_string_ex(sort);

	xp[0] = (*xparam);
	xp[1] = (*midgard_user_call_func_name);
	RETVAL_LONG(
		mgd_walk_table_tree(mgd_handle(),
				mgd_table_name[(*tableid)->value.lval],
									(*upfield)->value.str.val,
									(*id)->value.lval,
									(*level)->value.lval,
									order ? (*order)->value.lval : 1,
									(void *)xp,
									midgard_user_call_func,
									sort ? (*sort)->value.str.val : NULL)
	);
}
#endif /* YOU_WANT_TO_TEST */
#endif	/* HAVE_MIDGARD */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
