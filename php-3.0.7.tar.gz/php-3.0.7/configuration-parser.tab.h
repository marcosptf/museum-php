#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	STRING	257
#define	ENCAPSULATED_STRING	258
#define	SECTION	259
#define	CFG_TRUE	260
#define	CFG_FALSE	261
#define	EXTENSION	262

